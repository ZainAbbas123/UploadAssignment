# include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
     FILE*fptr;
     char filename[100]="\0";
      char filename1[100]="\0";
     char ch;
    fptr=fopen("ss3.txt","r");
       if(fptr==NULL){
          printf("Cannot open file \n");
          exit(0);
       }
       int k;
       char far[100];
       ch = fgetc(fptr);
       while(fgets(far,sizeof(filename),fptr))
       {
          strcat(filename,far);
          strcat(filename," ");
       }
       filename[strlen(filename)-1] = '\0';
          int count1=0;
          int h;      
          int j;
          int j1=0;
          int j2=0;
          int n2=0;
          int h1=0;
          int h3;
          int count3=0;
          int x=strlen(filename);
     
       int h1_1=0;
       int h5=0;
       int n6=0;
      int i=0,n4=0,n=0;
      int g;
      for(i=0;i<strlen(filename)+1;i++)
      {
              if(filename[n]==' ' || filename[n]=='\0'){    
                 for(j1=j;j1>=h1;j1--)
                 {
                       if(filename[j1]=='a'|| filename[j1]=='e'|| filename[j1]=='i'|| filename[j1]=='o'|| filename[j1]=='u'){
                                   count3++;
                              }
                }
                if(count3!=0)
                {
                    h3 = n;
                     for(n4=h1;n4<n;n4++){
                         filename1[h3-1] = filename[n4];
                         h3--;
                        }  
                h1 = n;
                }
          } 
          n++;
          j++;
      }
      for(g=0;g<n;g++)
     {
           filename[h5] = filename1[g];
           h5++;
    } 
    printf("filename is %s",filename);       
    return 0;
    }  
