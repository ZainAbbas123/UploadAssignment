#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc,char *argv[])
{
     int i=0,j=0;
     int count1=0;
     char arr4[10][100];
     
    for(i=1;argv[i]!=0;i++)
    {
     for(j=0;argv[i][j]!='\0';j++)
     {
       arr4[i-1][j]=argv[i][j];
     }
        arr4[i][j]='\0';    
    }
     arr4[i][0]='\0';
     
     
     for(i=0;arr4[i][0]!='\0';i++)
     {
            count1++;
     }
     
     // Printing of Student Data
    for(i=0;i<count1;i++)
    {
    	printf("%s",arr4[i]);
    	printf("  \n");
    }
    
      char name4[10][50];
     int a=0;
     int k=0;
     int t=0;
     printf("\nPress 0 if you want add some student\n");
     printf("Press 1 if  you want delete student\n");
     printf("Press 2 If you want show data of some datas");
     scanf("%d",&a);
     
   int  h1=0;
   // Add Students into a file
   if(a==0)
   {
        int i=0;
       printf("count is %d",count1);
      printf("Enter your name,rollno and email of a student");
      
      FILE * fptr1=fopen("write1.txt","w");
      printf("Printing of all the students");
      for(i=0;i<3;i++)
      { 
       scanf("%s",name4[i]);
      }
      
      
    // Writing data into file
        for(i=count1;i<count1+3;i++)
      {
       strcpy(arr4[i],name4[h1]);
       fputs(arr4[i],fptr1);
       fputs(" ",fptr1);
       h1++; 
       
      }
       for(i=0;i<count1+3;i++)
      {
       printf("%s \n:",arr4[i]);
      }      
   }
   
   int n=0;
   if(a==1){
    char ar[10][50];
      printf("enter student no u want to delete ");
      scanf("%d",&n);
       int yu=n*3;
      int m=n*3;
      FILE * fptr=fopen("write2.txt","w");
      printf("%d",count1);
      for(i=0;i<count1;i++)
      {
             if(i==m || i==m+1||i==m+2)
             {
                 // break all conditions
               }
            else
            {
            // Copy those data which is not matching
              strcpy(ar[k],arr4[i]);
              printf("%s\n",ar[k]);  
              fputs(ar[k],fptr);
             k++;
            }   
       }     
   }
   if(a==2)
   {
     printf("Enter Num of that student u want to see data");
      FILE * fptr1=fopen("write.txt","w");
     scanf("%d",&k);
      t=k*3;
      
      // Writing data into file
      for(i=t;i<t+3;i++){
       if(i==t|| i==t+1||i==t+2)
       { 
       printf("%d",t);
          printf(":%s",arr4[i]);
        fputs(arr4[i],fptr1);
       fputs(" ",fptr1);
       }   
     }
   }
   
    return 0;
}
