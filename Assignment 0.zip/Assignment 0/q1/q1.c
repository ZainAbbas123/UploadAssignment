# include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
     FILE*fptr;
     char filename[100];
     char ch;
     fptr=fopen("ss.txt","r");
       if(fptr==NULL){
          printf("Cannot open file \n");
          exit(0);
       }
       int k;
       ch = fgetc(fptr);
       while(ch!=EOF){
          printf("%c",ch);
          filename[k++]=ch;
          ch=fgetc(fptr);
      } 
        int count=0;
      printf("filename is %s",filename);
      int i=0;
      int n=0;
      for(i=0;i<filename[i];i++){
      if(filename[i]>='0' && filename[i]<='9'){
                count++;
          }
        }
        printf("Count is %d",count);  
      return 0;
  }

